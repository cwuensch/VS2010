//-----------------------------------------------------------------------------
// File:		adoid.h
//
// Copyright:	Copyright (c) Microsoft Corporation 
//
// Contents:	ADO Guids.	
//-----------------------------------------------------------------------------

#ifndef _ADOID_H_
#define _ADOID_H_
#include "adodef.h"
#include "ADOGuids.h"
#endif // _ADOID_H_

