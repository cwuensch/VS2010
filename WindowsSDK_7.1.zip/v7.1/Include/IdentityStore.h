

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 7.00.0555 */
/* Compiler settings for identitystore.idl:
    Oicf, W1, Zp8, env=Win32 (32b run), target_arch=X86 7.00.0555 
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
/* @@MIDL_FILE_HEADING(  ) */

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 500
#endif

/* verify that the <rpcsal.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCSAL_H_VERSION__
#define __REQUIRED_RPCSAL_H_VERSION__ 100
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __identitystore_h__
#define __identitystore_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __IIdentityStore_FWD_DEFINED__
#define __IIdentityStore_FWD_DEFINED__
typedef interface IIdentityStore IIdentityStore;
#endif 	/* __IIdentityStore_FWD_DEFINED__ */


#ifndef __AsyncIIdentityStore_FWD_DEFINED__
#define __AsyncIIdentityStore_FWD_DEFINED__
typedef interface AsyncIIdentityStore AsyncIIdentityStore;
#endif 	/* __AsyncIIdentityStore_FWD_DEFINED__ */


#ifndef __CoClassIdentityStore_FWD_DEFINED__
#define __CoClassIdentityStore_FWD_DEFINED__

#ifdef __cplusplus
typedef class CoClassIdentityStore CoClassIdentityStore;
#else
typedef struct CoClassIdentityStore CoClassIdentityStore;
#endif /* __cplusplus */

#endif 	/* __CoClassIdentityStore_FWD_DEFINED__ */


#ifndef __CIdentityProfileHandler_FWD_DEFINED__
#define __CIdentityProfileHandler_FWD_DEFINED__

#ifdef __cplusplus
typedef class CIdentityProfileHandler CIdentityProfileHandler;
#else
typedef struct CIdentityProfileHandler CIdentityProfileHandler;
#endif /* __cplusplus */

#endif 	/* __CIdentityProfileHandler_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"
#include "propsys.h"
#include "IdentityCommon.h"

#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IIdentityStore_INTERFACE_DEFINED__
#define __IIdentityStore_INTERFACE_DEFINED__

/* interface IIdentityStore */
/* [unique][helpstring][async_uuid][uuid][object] */ 


EXTERN_C const IID IID_IIdentityStore;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("df586fa5-6f35-44f1-b209-b38e169772eb")
    IIdentityStore : public IUnknown
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE GetCount( 
            /* [out] */ __RPC__out DWORD *pdwProviders) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE GetAt( 
            /* [in] */ const DWORD dwProvider,
            /* [unique][out][in] */ __RPC__inout_opt GUID *pProvGuid,
            /* [out] */ __RPC__deref_out_opt IUnknown **ppIdentityProvider) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE AddToCache( 
            /* [in] */ __RPC__in LPCWSTR lpszUniqueID,
            /* [in] */ __RPC__in REFGUID ProviderGUID) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE ConvertToSid( 
            /* [in] */ __RPC__in LPCWSTR lpszUniqueID,
            /* [in] */ __RPC__in REFGUID ProviderGUID,
            /* [in] */ USHORT cbSid,
            /* [size_is][unique][out][in] */ __RPC__inout_ecount_full_opt(cbSid) BYTE *pSid,
            /* [out] */ __RPC__out USHORT *pcbRequiredSid) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE EnumerateIdentities( 
            /* [in] */ const IDENTITY_TYPE eIdentityType,
            /* [unique][in] */ __RPC__in_opt const PROPERTYKEY *pFilterkey,
            /* [unique][in] */ __RPC__in_opt const PROPVARIANT *pFilterPropVarValue,
            /* [out] */ __RPC__deref_out_opt IEnumUnknown **ppIdentityEnum) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Reset( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IIdentityStoreVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            __RPC__in IIdentityStore * This,
            /* [in] */ __RPC__in REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            __RPC__in IIdentityStore * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            __RPC__in IIdentityStore * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetCount )( 
            __RPC__in IIdentityStore * This,
            /* [out] */ __RPC__out DWORD *pdwProviders);
        
        HRESULT ( STDMETHODCALLTYPE *GetAt )( 
            __RPC__in IIdentityStore * This,
            /* [in] */ const DWORD dwProvider,
            /* [unique][out][in] */ __RPC__inout_opt GUID *pProvGuid,
            /* [out] */ __RPC__deref_out_opt IUnknown **ppIdentityProvider);
        
        HRESULT ( STDMETHODCALLTYPE *AddToCache )( 
            __RPC__in IIdentityStore * This,
            /* [in] */ __RPC__in LPCWSTR lpszUniqueID,
            /* [in] */ __RPC__in REFGUID ProviderGUID);
        
        HRESULT ( STDMETHODCALLTYPE *ConvertToSid )( 
            __RPC__in IIdentityStore * This,
            /* [in] */ __RPC__in LPCWSTR lpszUniqueID,
            /* [in] */ __RPC__in REFGUID ProviderGUID,
            /* [in] */ USHORT cbSid,
            /* [size_is][unique][out][in] */ __RPC__inout_ecount_full_opt(cbSid) BYTE *pSid,
            /* [out] */ __RPC__out USHORT *pcbRequiredSid);
        
        HRESULT ( STDMETHODCALLTYPE *EnumerateIdentities )( 
            __RPC__in IIdentityStore * This,
            /* [in] */ const IDENTITY_TYPE eIdentityType,
            /* [unique][in] */ __RPC__in_opt const PROPERTYKEY *pFilterkey,
            /* [unique][in] */ __RPC__in_opt const PROPVARIANT *pFilterPropVarValue,
            /* [out] */ __RPC__deref_out_opt IEnumUnknown **ppIdentityEnum);
        
        HRESULT ( STDMETHODCALLTYPE *Reset )( 
            __RPC__in IIdentityStore * This);
        
        END_INTERFACE
    } IIdentityStoreVtbl;

    interface IIdentityStore
    {
        CONST_VTBL struct IIdentityStoreVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IIdentityStore_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define IIdentityStore_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define IIdentityStore_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define IIdentityStore_GetCount(This,pdwProviders)	\
    ( (This)->lpVtbl -> GetCount(This,pdwProviders) ) 

#define IIdentityStore_GetAt(This,dwProvider,pProvGuid,ppIdentityProvider)	\
    ( (This)->lpVtbl -> GetAt(This,dwProvider,pProvGuid,ppIdentityProvider) ) 

#define IIdentityStore_AddToCache(This,lpszUniqueID,ProviderGUID)	\
    ( (This)->lpVtbl -> AddToCache(This,lpszUniqueID,ProviderGUID) ) 

#define IIdentityStore_ConvertToSid(This,lpszUniqueID,ProviderGUID,cbSid,pSid,pcbRequiredSid)	\
    ( (This)->lpVtbl -> ConvertToSid(This,lpszUniqueID,ProviderGUID,cbSid,pSid,pcbRequiredSid) ) 

#define IIdentityStore_EnumerateIdentities(This,eIdentityType,pFilterkey,pFilterPropVarValue,ppIdentityEnum)	\
    ( (This)->lpVtbl -> EnumerateIdentities(This,eIdentityType,pFilterkey,pFilterPropVarValue,ppIdentityEnum) ) 

#define IIdentityStore_Reset(This)	\
    ( (This)->lpVtbl -> Reset(This) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IIdentityStore_INTERFACE_DEFINED__ */


#ifndef __AsyncIIdentityStore_INTERFACE_DEFINED__
#define __AsyncIIdentityStore_INTERFACE_DEFINED__

/* interface AsyncIIdentityStore */
/* [uuid][unique][helpstring][object] */ 


EXTERN_C const IID IID_AsyncIIdentityStore;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("eefa1616-48de-4872-aa64-6e6206535a51")
    AsyncIIdentityStore : public IUnknown
    {
    public:
        virtual HRESULT STDMETHODCALLTYPE Begin_GetCount( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Finish_GetCount( 
            /* [out] */ __RPC__out DWORD *pdwProviders) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Begin_GetAt( 
            /* [in] */ const DWORD dwProvider,
            /* [unique][out][in] */ __RPC__inout_opt GUID *pProvGuid) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Finish_GetAt( 
            /* [unique][out][in] */ __RPC__inout_opt GUID *pProvGuid,
            /* [out] */ __RPC__deref_out_opt IUnknown **ppIdentityProvider) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Begin_AddToCache( 
            /* [in] */ __RPC__in LPCWSTR lpszUniqueID,
            /* [in] */ __RPC__in REFGUID ProviderGUID) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Finish_AddToCache( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Begin_ConvertToSid( 
            /* [in] */ __RPC__in LPCWSTR lpszUniqueID,
            /* [in] */ __RPC__in REFGUID ProviderGUID,
            /* [in] */ USHORT cbSid,
            /* [size_is][unique][out][in] */ __RPC__inout_xcount_full_opt(cbSid) BYTE *pSid) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Finish_ConvertToSid( 
            /* [size_is][unique][out][in] */ __RPC__inout_xcount_full_opt(cbSid) BYTE *pSid,
            /* [out] */ __RPC__out USHORT *pcbRequiredSid) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Begin_EnumerateIdentities( 
            /* [in] */ const IDENTITY_TYPE eIdentityType,
            /* [unique][in] */ __RPC__in_opt const PROPERTYKEY *pFilterkey,
            /* [unique][in] */ __RPC__in_opt const PROPVARIANT *pFilterPropVarValue) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Finish_EnumerateIdentities( 
            /* [out] */ __RPC__deref_out_opt IEnumUnknown **ppIdentityEnum) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Begin_Reset( void) = 0;
        
        virtual HRESULT STDMETHODCALLTYPE Finish_Reset( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct AsyncIIdentityStoreVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            __RPC__in AsyncIIdentityStore * This,
            /* [in] */ __RPC__in REFIID riid,
            /* [annotation][iid_is][out] */ 
            __RPC__deref_out  void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            __RPC__in AsyncIIdentityStore * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            __RPC__in AsyncIIdentityStore * This);
        
        HRESULT ( STDMETHODCALLTYPE *Begin_GetCount )( 
            __RPC__in AsyncIIdentityStore * This);
        
        HRESULT ( STDMETHODCALLTYPE *Finish_GetCount )( 
            __RPC__in AsyncIIdentityStore * This,
            /* [out] */ __RPC__out DWORD *pdwProviders);
        
        HRESULT ( STDMETHODCALLTYPE *Begin_GetAt )( 
            __RPC__in AsyncIIdentityStore * This,
            /* [in] */ const DWORD dwProvider,
            /* [unique][out][in] */ __RPC__inout_opt GUID *pProvGuid);
        
        HRESULT ( STDMETHODCALLTYPE *Finish_GetAt )( 
            __RPC__in AsyncIIdentityStore * This,
            /* [unique][out][in] */ __RPC__inout_opt GUID *pProvGuid,
            /* [out] */ __RPC__deref_out_opt IUnknown **ppIdentityProvider);
        
        HRESULT ( STDMETHODCALLTYPE *Begin_AddToCache )( 
            __RPC__in AsyncIIdentityStore * This,
            /* [in] */ __RPC__in LPCWSTR lpszUniqueID,
            /* [in] */ __RPC__in REFGUID ProviderGUID);
        
        HRESULT ( STDMETHODCALLTYPE *Finish_AddToCache )( 
            __RPC__in AsyncIIdentityStore * This);
        
        HRESULT ( STDMETHODCALLTYPE *Begin_ConvertToSid )( 
            __RPC__in AsyncIIdentityStore * This,
            /* [in] */ __RPC__in LPCWSTR lpszUniqueID,
            /* [in] */ __RPC__in REFGUID ProviderGUID,
            /* [in] */ USHORT cbSid,
            /* [size_is][unique][out][in] */ __RPC__inout_xcount_full_opt(cbSid) BYTE *pSid);
        
        HRESULT ( STDMETHODCALLTYPE *Finish_ConvertToSid )( 
            __RPC__in AsyncIIdentityStore * This,
            /* [size_is][unique][out][in] */ __RPC__inout_xcount_full_opt(cbSid) BYTE *pSid,
            /* [out] */ __RPC__out USHORT *pcbRequiredSid);
        
        HRESULT ( STDMETHODCALLTYPE *Begin_EnumerateIdentities )( 
            __RPC__in AsyncIIdentityStore * This,
            /* [in] */ const IDENTITY_TYPE eIdentityType,
            /* [unique][in] */ __RPC__in_opt const PROPERTYKEY *pFilterkey,
            /* [unique][in] */ __RPC__in_opt const PROPVARIANT *pFilterPropVarValue);
        
        HRESULT ( STDMETHODCALLTYPE *Finish_EnumerateIdentities )( 
            __RPC__in AsyncIIdentityStore * This,
            /* [out] */ __RPC__deref_out_opt IEnumUnknown **ppIdentityEnum);
        
        HRESULT ( STDMETHODCALLTYPE *Begin_Reset )( 
            __RPC__in AsyncIIdentityStore * This);
        
        HRESULT ( STDMETHODCALLTYPE *Finish_Reset )( 
            __RPC__in AsyncIIdentityStore * This);
        
        END_INTERFACE
    } AsyncIIdentityStoreVtbl;

    interface AsyncIIdentityStore
    {
        CONST_VTBL struct AsyncIIdentityStoreVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define AsyncIIdentityStore_QueryInterface(This,riid,ppvObject)	\
    ( (This)->lpVtbl -> QueryInterface(This,riid,ppvObject) ) 

#define AsyncIIdentityStore_AddRef(This)	\
    ( (This)->lpVtbl -> AddRef(This) ) 

#define AsyncIIdentityStore_Release(This)	\
    ( (This)->lpVtbl -> Release(This) ) 


#define AsyncIIdentityStore_Begin_GetCount(This)	\
    ( (This)->lpVtbl -> Begin_GetCount(This) ) 

#define AsyncIIdentityStore_Finish_GetCount(This,pdwProviders)	\
    ( (This)->lpVtbl -> Finish_GetCount(This,pdwProviders) ) 

#define AsyncIIdentityStore_Begin_GetAt(This,dwProvider,pProvGuid)	\
    ( (This)->lpVtbl -> Begin_GetAt(This,dwProvider,pProvGuid) ) 

#define AsyncIIdentityStore_Finish_GetAt(This,pProvGuid,ppIdentityProvider)	\
    ( (This)->lpVtbl -> Finish_GetAt(This,pProvGuid,ppIdentityProvider) ) 

#define AsyncIIdentityStore_Begin_AddToCache(This,lpszUniqueID,ProviderGUID)	\
    ( (This)->lpVtbl -> Begin_AddToCache(This,lpszUniqueID,ProviderGUID) ) 

#define AsyncIIdentityStore_Finish_AddToCache(This)	\
    ( (This)->lpVtbl -> Finish_AddToCache(This) ) 

#define AsyncIIdentityStore_Begin_ConvertToSid(This,lpszUniqueID,ProviderGUID,cbSid,pSid)	\
    ( (This)->lpVtbl -> Begin_ConvertToSid(This,lpszUniqueID,ProviderGUID,cbSid,pSid) ) 

#define AsyncIIdentityStore_Finish_ConvertToSid(This,pSid,pcbRequiredSid)	\
    ( (This)->lpVtbl -> Finish_ConvertToSid(This,pSid,pcbRequiredSid) ) 

#define AsyncIIdentityStore_Begin_EnumerateIdentities(This,eIdentityType,pFilterkey,pFilterPropVarValue)	\
    ( (This)->lpVtbl -> Begin_EnumerateIdentities(This,eIdentityType,pFilterkey,pFilterPropVarValue) ) 

#define AsyncIIdentityStore_Finish_EnumerateIdentities(This,ppIdentityEnum)	\
    ( (This)->lpVtbl -> Finish_EnumerateIdentities(This,ppIdentityEnum) ) 

#define AsyncIIdentityStore_Begin_Reset(This)	\
    ( (This)->lpVtbl -> Begin_Reset(This) ) 

#define AsyncIIdentityStore_Finish_Reset(This)	\
    ( (This)->lpVtbl -> Finish_Reset(This) ) 

#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __AsyncIIdentityStore_INTERFACE_DEFINED__ */



#ifndef __IdentityStoreLib_LIBRARY_DEFINED__
#define __IdentityStoreLib_LIBRARY_DEFINED__

/* library IdentityStoreLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_IdentityStoreLib;

EXTERN_C const CLSID CLSID_CoClassIdentityStore;

#ifdef __cplusplus

class DECLSPEC_UUID("30d49246-d217-465f-b00b-ac9ddd652eb7")
CoClassIdentityStore;
#endif

EXTERN_C const CLSID CLSID_CIdentityProfileHandler;

#ifdef __cplusplus

class DECLSPEC_UUID("ecf5bf46-e3b6-449a-b56b-43f58f867814")
CIdentityProfileHandler;
#endif
#endif /* __IdentityStoreLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     __RPC__in unsigned long *, unsigned long            , __RPC__in BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserMarshal(  __RPC__in unsigned long *, __RPC__inout_xcount(0) unsigned char *, __RPC__in BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserUnmarshal(__RPC__in unsigned long *, __RPC__in_xcount(0) unsigned char *, __RPC__out BSTR * ); 
void                      __RPC_USER  BSTR_UserFree(     __RPC__in unsigned long *, __RPC__in BSTR * ); 

unsigned long             __RPC_USER  LPSAFEARRAY_UserSize(     __RPC__in unsigned long *, unsigned long            , __RPC__in LPSAFEARRAY * ); 
unsigned char * __RPC_USER  LPSAFEARRAY_UserMarshal(  __RPC__in unsigned long *, __RPC__inout_xcount(0) unsigned char *, __RPC__in LPSAFEARRAY * ); 
unsigned char * __RPC_USER  LPSAFEARRAY_UserUnmarshal(__RPC__in unsigned long *, __RPC__in_xcount(0) unsigned char *, __RPC__out LPSAFEARRAY * ); 
void                      __RPC_USER  LPSAFEARRAY_UserFree(     __RPC__in unsigned long *, __RPC__in LPSAFEARRAY * ); 

unsigned long             __RPC_USER  BSTR_UserSize64(     __RPC__in unsigned long *, unsigned long            , __RPC__in BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserMarshal64(  __RPC__in unsigned long *, __RPC__inout_xcount(0) unsigned char *, __RPC__in BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserUnmarshal64(__RPC__in unsigned long *, __RPC__in_xcount(0) unsigned char *, __RPC__out BSTR * ); 
void                      __RPC_USER  BSTR_UserFree64(     __RPC__in unsigned long *, __RPC__in BSTR * ); 

unsigned long             __RPC_USER  LPSAFEARRAY_UserSize64(     __RPC__in unsigned long *, unsigned long            , __RPC__in LPSAFEARRAY * ); 
unsigned char * __RPC_USER  LPSAFEARRAY_UserMarshal64(  __RPC__in unsigned long *, __RPC__inout_xcount(0) unsigned char *, __RPC__in LPSAFEARRAY * ); 
unsigned char * __RPC_USER  LPSAFEARRAY_UserUnmarshal64(__RPC__in unsigned long *, __RPC__in_xcount(0) unsigned char *, __RPC__out LPSAFEARRAY * ); 
void                      __RPC_USER  LPSAFEARRAY_UserFree64(     __RPC__in unsigned long *, __RPC__in LPSAFEARRAY * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif



