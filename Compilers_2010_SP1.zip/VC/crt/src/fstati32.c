/***
*fstati32.c - return file status info
*
*       Copyright (c) Microsoft Corporation. All rights reserved.
*
*Purpose:
*       defines _fstat64i32() - return file status info
*
*******************************************************************************/

#define _USE_INT64  0

#include "fstat64.c"
