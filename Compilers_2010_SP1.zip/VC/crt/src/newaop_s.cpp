/***
*newaop_s.cpp - version of newaop.cpp for DLL library
*
*	Copyright (c) Microsoft Corporation. All rights reserved.
*
*Purpose:
*	Version of newaop.cpp for DLL library
*
*******************************************************************************/

#undef	CRTDLL2

#include "newaop.cpp"
