/***
*execve.c - execute a file with a given environment
*
*       Copyright (c) Microsoft Corporation. All rights reserved.
*
*Purpose:
*       defines _execve() - execute a file
*
*******************************************************************************/

#define EXECVE

#include "spawnve.c"
