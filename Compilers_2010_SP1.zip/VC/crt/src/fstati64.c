/***
*fstati64.c - return file status info
*
*       Copyright (c) Microsoft Corporation. All rights reserved.
*
*Purpose:
*       defines _fstati64() - return file status info
*
*******************************************************************************/

#define _USE_INT64  1

#include "fstat.c"
