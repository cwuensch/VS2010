// instances -- force DLL instances for Microsoft
#define __FORCE_INSTANCE

#include <ios>
#include <istream>
#include <locale>
#include <ostream>
#include <streambuf>
#include <xlocale>
#include <xlocmes>
#include <xlocmon>
#include <xlocnum>
#include <xloctime>

_STD_BEGIN

template class _CRTIMP2_PURE _Yarn<char>;

_STD_END

/*
 * Copyright (c) 1992-2007 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
 V5.03:0009 */
