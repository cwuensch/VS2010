/***
*cwscanfs.c - Conio version of wscanf_s
*
*       Copyright (c) Microsoft Corporation.  All rights reserved.
*
*Purpose:
*       This takes a size from the argument list for all string inputs.
*
*******************************************************************************/

#define CPRFLAG 1
#define _SECURE_SCANF 1
#include "winput.c"
