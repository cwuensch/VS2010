#define STDCPP_IMPLIB 1
#include "locale.cpp"
