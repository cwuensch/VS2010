/***
*newop_s.cpp - version of newop.cpp for DLL library
*
*	Copyright (c) Microsoft Corporation. All rights reserved.
*
*Purpose:
*	Version of newop.cpp for DLL library
*
*******************************************************************************/

#undef	CRTDLL2

#include "newop.cpp"
