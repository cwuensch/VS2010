/***
*fndfi32.c - C find file functions (wchar_t version)
*
*       Copyright (c) Microsoft Corporation. All rights reserved.
*
*Purpose:
*       Defines _findfirst64i32() and _findnext64i32().
*
*******************************************************************************/

#define _USE_INT64 0

#include "findf64.c"
