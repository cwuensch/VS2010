/***
* fp8.c - Set default FP precision
*
*       Copyright (c) Microsoft Corporation.  All rights reserved.
*
*Purpose:
*
*******************************************************************************/
#include <float.h>
#include <internal.h>

void  _setdefaultprecision(void);

/*
 * Routine to set default FP precision to 64 bits.
 */

void _setdefaultprecision()
{
        _ERRCHECK(_controlfp_s(NULL, _PC_64, _MCW_PC));
}

